import tkinter as tk
from tkinter import messagebox
import threading
import rospy
import paramiko
import os
import time

# SSH configuration
DRONE_HOST = 'drone_ip_address'
DRONE_PORT = 22
DRONE_USER = 'username'
DRONE_KEY = '/path/to/private/key'  # Path to SSH private key

# Function to execute a command via SSH
def execute_ssh_command(host, port, user, key_path, command):
    try:
        key = paramiko.RSAKey.from_private_key_file(key_path)
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, port, username=user, pkey=key)
        ssh.exec_command("cd catkin_ws/src/Solar_Drone_System/src")
        stdin, stdout, stderr = ssh.exec_command(command)
        result = stdout.read().decode()
        ssh.close()
        return result
    except Exception as e:
        return str(e)

# Local node management functions
def start_local_node(node_name, bootstrap_function):
    if node_name in threads and threads[node_name].is_alive():
        messagebox.showinfo("Info", f"{node_name} is already running")
        return

    rospy.init_node(f"{node_name}_node", anonymous=True)
    thread = threading.Thread(target=bootstrap_function)
    thread.start()
    threads[node_name] = thread
    messagebox.showinfo("Execution", f"{node_name} started")

def stop_local_node(node_name):
    if node_name in threads and threads[node_name].is_alive():
        rospy.signal_shutdown(f"{node_name} shutdown")
        threads[node_name].join()
        messagebox.showinfo("Execution", f"{node_name} stopped")
    else:
        messagebox.showinfo("Info", f"{node_name} is not running")

# Remote node management functions
def start_remote_node(node_name, command):
    result = execute_ssh_command(DRONE_HOST, DRONE_PORT, DRONE_USER, DRONE_KEY, command)
    messagebox.showinfo("Execution", f"Started {node_name} on drone:\n{result}")

def stop_remote_node(node_name, command):
    result = execute_ssh_command(DRONE_HOST, DRONE_PORT, DRONE_USER, DRONE_KEY, command)
    messagebox.showinfo("Execution", f"Stopped {node_name} on drone:\n{result}")

# Creating the main window
root = tk.Tk()
root.title("ROS Node Manager")

# Thread dictionary to store running threads
threads = {}

# Local node buttons
button1_start = tk.Button(root, text="Start Local Camera Reader Node", command=lambda: start_local_node("camera_reader", camera_reader_bootstrap.bootstrap))
button1_stop = tk.Button(root, text="Stop Local Camera Reader Node", command=lambda: stop_local_node("camera_reader"))
button2_start = tk.Button(root, text="Start Local LiDAR Reader Node", command=lambda: start_local_node("lidar_reader", lidar_reader_bootstrap.bootstrap))
button2_stop = tk.Button(root, text="Stop Local LiDAR Reader Node", command=lambda: stop_local_node("lidar_reader"))
button3_start = tk.Button(root, text="Start Local GPS Reader Node", command=lambda: start_local_node("gps_reader", gps_reader_bootstrap.bootstrap))
button3_stop = tk.Button(root, text="Stop Local GPS Reader Node", command=lambda: stop_local_node("gps_reader"))

# Remote node buttons
button4_start = tk.Button(root, text="Start Drone Camera Reader Node", command=lambda: start_remote_node("drone_camera_reader", "python3 /path/to/drone/camera_reader_bootstrap.py"))
button4_stop = tk.Button(root, text="Stop Drone Camera Reader Node", command=lambda: stop_remote_node("drone_camera_reader", "pkill -f camera_reader_bootstrap.py"))
button5_start = tk.Button(root, text="Start Drone LiDAR Reader Node", command=lambda: start_remote_node("drone_lidar_reader", "python3 /path/to/drone/lidar_reader_bootstrap.py"))
button5_stop = tk.Button(root, text="Stop Drone LiDAR Reader Node", command=lambda: stop_remote_node("drone_lidar_reader", "pkill -f lidar_reader_bootstrap.py"))
button6_start = tk.Button(root, text="Start Drone GPS Reader Node", command=lambda: start_remote_node("drone_gps_reader", "python3 /path/to/drone/gps_reader_bootstrap.py"))
button6_stop = tk.Button(root, text="Stop Drone GPS Reader Node", command=lambda: stop_remote_node("drone_gps_reader", "pkill -f gps_reader_bootstrap.py"))

# Placing buttons on the window
button1_start.pack(pady=5)
button1_stop.pack(pady=5)
button2_start.pack(pady=5)
button2_stop.pack(pady=5)
button3_start.pack(pady=5)
button3_stop.pack(pady=5)
button4_start.pack(pady=5)
button4_stop.pack(pady=5)
button5_start.pack(pady=5)
button5_stop.pack(pady=5)
button6_start.pack(pady=5)
button6_stop.pack(pady=5)

# Running the main loop
root.mainloop()
